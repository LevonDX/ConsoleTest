﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumeratorTest
{
    class CarCollection : IEnumerable<Car>
    {
        private List<Car> internalCarCollection;

        public CarCollection()
        {
            internalCarCollection = new List<Car>();
        }

        public void Add(Car car)
        {
            internalCarCollection.Add(car);
        }

        public IEnumerator<Car> GetEnumerator()
        {
            return new CarCollectionEnumerator(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        class CarCollectionEnumerator : IEnumerator<Car>
        {
            private CarCollection carCollection;

            public CarCollectionEnumerator(CarCollection cars)
            {
                this.carCollection = cars;
            }

            private int currentIndex = -1;

            #region IEnumerator
            public bool MoveNext()
            {
                currentIndex++;
                return currentIndex < this.carCollection.internalCarCollection.Count;
            }

            public void Reset()
            {
                currentIndex = -1;
            }

            public Car Current
            {
                get
                {
                    return this.carCollection.internalCarCollection[currentIndex];
                }
            }

            public void Dispose()
            {

            }
            #endregion


            object IEnumerator.Current
            {
                get
                {
                    return this.Current;
                }
            }
        }

    }
}
